#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

using namespace std;

int main ()
{
	int n_alunos, n_alunas;
	
	printf("Digite o numero de alunos: ");
	scanf("%d", &n_alunos);
	
	printf("Digite o numero de alunas: ");
	scanf("%d", &n_alunas);
	
	printf("Numero de alunas: %d", n_alunas);
	printf("\n");
	printf("Numero de alunas: %d", n_alunos);
	
	
	getch();
}
