#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

using namespace std;

int main ()
{
	printf(" -- TABUADA DO NUMERO 3 -- ");
	printf("\n");
	
	printf(" 3 X 1 = %d\n", 3*1);
	printf(" 3 X 1 = %d\n", 3*2);
	printf(" 3 X 1 = %d\n", 3*3);
	printf(" 3 X 1 = %d\n", 3*4);
	printf(" 3 X 1 = %d\n", 3*5);
	printf(" 3 X 1 = %d\n", 3*6);
	printf(" 3 X 1 = %d\n", 3*7);
	printf(" 3 X 1 = %d\n", 3*8);
	printf(" 3 X 1 = %d\n", 3*9);
	printf(" 3 X 1 = %d\n", 3*10);
	
	getch();
}