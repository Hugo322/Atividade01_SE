#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(){
	int nike, adidas, puma;
	
	printf ("Digite o numero de chuteiras da Nike: ");
	scanf ("%d", &nike);
	
	printf ("Digite o numero de chuteiras da Adidas: ");
	scanf ("%d", &adidas);
	
	printf ("Digite o numero de chuteiras da Puma: ");
	scanf ("%d", &puma);
	
	printf("\n\n");
	
	printf("\t\t -- QUANTIADE DE CHUTEIRAS EM ESTOQUE --\n ");
	printf("\t\t\t Nike \t Adidas  Puma \n");
	printf("\t\t\t %d \t %d \t %d \n\n", nike, adidas, puma);
	getch();
}