#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(){
	int num;
	
	printf("Entre com o numero que deseja saber a tabuada: ");
	scanf("%d", &num);
	printf("\n\n");
	
	printf("\t\t -- TABUADA DO NUMERO %d -- \n\n", num);
	printf("\t\t\t %d x 1 = %d\n", num, num*1);
	printf("\t\t\t %d x 2 = %d\n", num, num*2);
	printf("\t\t\t %d x 3 = %d\n", num, num*3);
	printf("\t\t\t %d x 4 = %d\n", num, num*4);
	printf("\t\t\t %d x 5 = %d\n", num, num*5);
	printf("\t\t\t %d x 6 = %d\n", num, num*6);
	printf("\t\t\t %d x 7 = %d\n", num, num*7);
	printf("\t\t\t %d x 8 = %d\n", num, num*8);
	printf("\t\t\t %d x 9 = %d\n", num, num*9);
	printf("\t\t\t %d x 10 = %d\n", num, num*10);
	getch();
}
	
	