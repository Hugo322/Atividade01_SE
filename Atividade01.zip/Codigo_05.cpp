#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(){
	int num;
	
	printf("Escreva uma numero da base decimal: ");
	scanf("%d", &num);
	printf("\n\n");
	
	printf("O valor de %d na base octal: %o\n", num, num);
	printf("O valor de %d na base hexadecimal: %x\n", num, num);
	
	getch();
}	