#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main(){
	int tam;
	
	printf("Entre com um valor para o tamanho do quadrado: ");
	scanf("%d", &tam);
	
	
	
	printf("\n\n");
	
	printf("Area do quadrado: %d\n", tam*tam);
	printf("Perimetro do quadrado: %d\n", 4*tam);
	
	getch();
	
}